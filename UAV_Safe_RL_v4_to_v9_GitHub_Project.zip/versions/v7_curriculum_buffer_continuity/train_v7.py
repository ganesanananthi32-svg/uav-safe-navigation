from stable_baselines3 import SAC
from stable_baselines3.common.monitor import Monitor
from src.env import UAVNavigationEnv
from src.shield_wrapper import TrainingShieldWrapper
from config import STAGES, SEED, BUFFER_SIZE

def run():
    model=None
    replay_path=None
    for stage,(n,steps) in enumerate(STAGES,1):
        env=Monitor(TrainingShieldWrapper(UAVNavigationEnv(
            num_obstacles=n, seed=SEED, spacing_fix=False)))
        if model is None:
            model=SAC("MlpPolicy",env,learning_rate=3e-4,buffer_size=BUFFER_SIZE,
                      batch_size=256,tau=0.005,gamma=0.99,learning_starts=1000,
                      policy_kwargs=dict(net_arch=[128,128]),seed=SEED,verbose=1,device="cpu")
        else:
            model.set_env(env)
            model.load_replay_buffer(replay_path)
        model.learn(total_timesteps=steps,progress_bar=True)
        model.save(f"models/stage_{stage}.zip")
        replay_path=f"models/stage_{stage}_replay.pkl"
        model.save_replay_buffer(replay_path)
    return model

if __name__=="__main__":
    run()
