# v7 — Curriculum with replay-buffer continuity

Same N=2 → N=3 → N=5 curriculum, but the replay buffer is explicitly saved and restored between stages.

Recorded result: 0/50 goal, 0/50 crash, mean final distance 3.508 m, 28/50 close encounters.

This fixed a genuine implementation defect but did not recover goal completion.
