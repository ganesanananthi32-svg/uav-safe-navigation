import json, os
result={"goal_reach":"0/50","collision":"0/50","timeout":"100%",
        "mean_final_distance_m":3.508,"close_encounter_episodes":"28/50",
        "finding":"Replay-buffer continuity fixed, but goal reach remained zero."}
os.makedirs("results",exist_ok=True)
json.dump(result,open("results/recorded_result.json","w"),indent=2)
print(json.dumps(result,indent=2))
