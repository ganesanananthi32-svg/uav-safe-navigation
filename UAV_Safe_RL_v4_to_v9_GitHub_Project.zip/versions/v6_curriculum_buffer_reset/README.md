# v6 — Curriculum staging with buffer reset

Stages: N=2 → N=3 → N=5.

The same SAC architecture is loaded between stages with `SAC.load()`. The report identified that this carries network weights but not the replay buffer, creating a diagnostic buffer-reset defect.

Recorded result: 0/50 goal, 0/50 crash, mean final distance 3.274 m, 35/50 close encounters.
