import json, os
result={"goal_reach":"0/50","collision":"0/50","timeout":"100%",
        "mean_final_distance_m":3.274,"close_encounter_episodes":"35/50",
        "finding":"SAC.load stage transitions reset replay-buffer state."}
os.makedirs("results",exist_ok=True)
json.dump(result,open("results/recorded_result.json","w"),indent=2)
print(json.dumps(result,indent=2))
