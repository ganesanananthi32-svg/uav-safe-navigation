from src.train import train
from config import *

if __name__ == "__main__":
    train(total_steps=TOTAL_STEPS, obstacles=N_OBSTACLES, seed=SEED,
          shield_during_training=SHIELD_DURING_TRAINING,
          spacing_fix=SPACING_FIX, ttc_threshold=TTC_THRESHOLD,
          buffer_size=BUFFER_SIZE, model_dir="models")
