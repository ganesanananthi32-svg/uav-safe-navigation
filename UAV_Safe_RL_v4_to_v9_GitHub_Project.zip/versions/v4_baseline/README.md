# v4 — Five-obstacle baseline

**Change:** scaled five-obstacle configuration with the Phase-1 safety-filter training arrangement.

**Training:** 150,000 SAC steps, seed 42, 5 dynamic obstacles, 50,000 replay buffer.

**Recorded report result:** 0% goal, 2% collision, 98% timeout; mean final distance 2.581 m; mean closest approach 0.938 m.

The code is runnable. The JSON is a transcription of the verified report result, not a newly executed run.
