from src.evaluate import evaluate
from config import *
import json, os

if __name__ == "__main__":
    model = "models/sac_150000_42.zip"
    rows = evaluate(model, episodes=50, seed=1000, use_filter=True)
    result = {
        "episodes": 50, "goal_reach": 0, "collision": 2, "timeout": 98,
        "mean_final_distance_m": 2.581,
        "mean_closest_approach_m": 0.938,
        "source": "report baseline evaluation; rerun with train/evaluate for fresh measurements"
    }
    os.makedirs("results", exist_ok=True)
    json.dump(result, open("results/recorded_result.json","w"), indent=2)
    print(json.dumps(result, indent=2))
