from stable_baselines3 import SAC
from stable_baselines3.common.monitor import Monitor
from src.env import UAVNavigationEnv
from config import *

def main():
    # Corrected training: NO safety-filter action substitution occurs during
    # training. Therefore the action stored in SAC replay is the action that
    # actually produced the observed transition.
    env=Monitor(UAVNavigationEnv(num_obstacles=N_OBSTACLES, seed=SEED,
                                 spacing_fix=True, dt=DT,
                                 episode_len=EPISODE_STEPS,
                                 max_accel=MAX_ACCEL, max_speed=MAX_SPEED))
    model=SAC("MlpPolicy",env,learning_rate=3e-4,buffer_size=BUFFER_SIZE,
              batch_size=256,tau=0.005,gamma=0.99,learning_starts=1000,
              policy_kwargs=dict(net_arch=list(NETWORK)),seed=SEED,
              verbose=1,device="cpu")
    model.learn(total_timesteps=TOTAL_STEPS,progress_bar=True)
    model.save("models/final_stable_model")
    return model

if __name__=="__main__":
    main()
