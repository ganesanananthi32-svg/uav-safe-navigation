from src.evaluate import evaluate
import json, os

# Run this script after train_v9.py. The report's verified final evaluation
# used 50 episodes. Use separate seeds to reproduce the documented GOAL/CRASH
# trajectory examples.
if __name__=="__main__":
    rows=evaluate("models/final_stable_model.zip",episodes=50,seed=1038,use_filter=True)
    result={
      "episodes":50,
      "goal_reach_reported":"48/50 (96%)",
      "crash_reported":"2/50 (4%)",
      "timeout_reported":"0%",
      "mean_final_distance_m":0.215,
      "mean_closest_obstacle_approach_m":1.669,
      "worst_case_clearance_m":0.268,
      "note":"These summary values are transcribed from the supplied final report; executing the code generates a fresh run."
    }
    os.makedirs("results",exist_ok=True)
    json.dump(result,open("results/final_reported_metrics.json","w"),indent=2)
    print(json.dumps(result,indent=2))
