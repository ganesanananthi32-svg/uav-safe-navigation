import json, os
# Reported diagnostic outcome for the 300k-step continuation.
result={"training_steps":300000,"ttc_threshold_s":2.0,
        "goal_reach":0,"evaluation_episode_length":951,
        "mean_reward_range":"about -95 to +19",
        "conclusion":"No measurable goal-reach improvement"}
os.makedirs("results",exist_ok=True)
json.dump(result,open("results/recorded_result.json","w"),indent=2)
print(json.dumps(result,indent=2))
