# v5 — Training-budget extension + TTC relaxation

**Change:** 150k → 300k steps and TTC trigger threshold 1.2 s → 2.0 s.

**Recorded result:** goal reach remained 0%; evaluation episode length stayed pinned at 951 steps (full timeout) and mean evaluation reward oscillated roughly between -95 and +19.

This version is the direct diagnostic test described in the report.
