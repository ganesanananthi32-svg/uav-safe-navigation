# v8 — Obstacle-placement geometry fix

A minimum pairwise obstacle spacing of 0.45 m was added and verified before training.

Recorded result: goal reach 0/50, crash 0/50; mean final distance 2.924 m (final checkpoint) / 2.725 m (best checkpoint).

This was a real environment bug fix, but it did not explain the 0% goal-reach plateau.
