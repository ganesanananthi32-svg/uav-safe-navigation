import json, os
result={"goal_reach":"0/50","collision":"0/50",
        "mean_final_distance_final_m":2.924,
        "mean_final_distance_best_m":2.725,
        "finding":"Minimum obstacle spacing 0.45 m removed overlap/nearly-overlap placements but did not recover goal reach."}
os.makedirs("results",exist_ok=True)
json.dump(result,open("results/recorded_result.json","w"),indent=2)
print(json.dumps(result,indent=2))
