
import numpy as np

try:
    import cvxpy as cp
except ImportError:
    cp = None

class CBFShield:
    """Acceleration-space CBF-QP shield.

    The nominal action is preserved whenever the nearest obstacle is outside
    the barrier margin. Near/closing obstacles are projected to a safer
    acceleration. CVXPY/OSQP is used when available; a deterministic fallback
    is provided for lightweight testing.
    """
    def __init__(self, safe_distance=0.55, gamma=3.0, max_accel=3.0,
                 slack_weight=5000.0):
        self.safe_distance = safe_distance
        self.gamma = gamma
        self.max_accel = max_accel
        self.slack_weight = slack_weight

    def filter(self, u_des, p, v, p_obs, v_obs):
        u_des = np.asarray(u_des, dtype=float)
        p_rel = np.asarray(p_obs)-np.asarray(p)
        v_rel = np.asarray(v_obs)-np.asarray(v)
        d = np.linalg.norm(p_rel)
        closing = np.dot(p_rel, v_rel) < 0
        h = d*d-self.safe_distance**2
        active = h <= 0.5 or (closing and d < 1.5)
        if not active:
            return np.clip(u_des, -self.max_accel, self.max_accel), False
        if cp is None:
            # Conservative deterministic fallback.
            direction = p_rel/(d+1e-8)
            away = -direction
            u = u_des.copy()
            toward = np.dot(u, direction)
            if toward > 0:
                u -= toward*direction
            u += 0.25*away
            return np.clip(u, -self.max_accel, self.max_accel), True

        u = cp.Variable(3)
        s = cp.Variable(nonneg=True)
        # Relative acceleration constraint: hdot + gamma*h >= -s.
        hdot = 2.0*p_rel @ (v_rel + u)
        constraint = [hdot + self.gamma*h + s >= 0,
                      u <= self.max_accel, u >= -self.max_accel]
        prob = cp.Problem(cp.Minimize(cp.sum_squares(u-u_des)+self.slack_weight*cp.square(s)),
                          constraint)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            if u.value is not None:
                return np.asarray(u.value).reshape(3), True
        except Exception:
            pass
        return np.clip(u_des, -self.max_accel, self.max_accel), True
