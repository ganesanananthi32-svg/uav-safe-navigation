
import numpy as np

class EventTrigger:
    def __init__(self, d_et=1.0, epsilon=1.0, cooldown_steps=15,
                 ttc_threshold=1.2, hard_floor=0.4, sensing_radius=3.0,
                 use_ttc_gate=True):
        self.d_et = d_et
        self.epsilon = epsilon
        self.cooldown_steps = cooldown_steps
        self.ttc_threshold = ttc_threshold
        self.hard_floor = hard_floor
        self.sensing_radius = sensing_radius
        self.use_ttc_gate = use_ttc_gate
        self.last_trigger = -10**9

    def reset(self):
        self.last_trigger = -10**9

    def should_trigger(self, step, p, obstacles):
        p = np.asarray(p)
        dmin = np.inf
        ttc = np.inf
        for po, vo in obstacles:
            r = np.asarray(po)-p
            d = np.linalg.norm(r)
            dmin = min(dmin, d)
            if d <= self.sensing_radius:
                vr = np.asarray(vo)
                closing = -np.dot(r, vr)/(d+1e-8)
                if closing > 0:
                    ttc = min(ttc, d/closing)
        if dmin <= self.hard_floor:
            self.last_trigger = step
            return True
        if step-self.last_trigger < self.cooldown_steps:
            return False
        if dmin <= self.d_et:
            self.last_trigger = step
            return True
        if self.use_ttc_gate and ttc < self.ttc_threshold:
            self.last_trigger = step
            return True
        return False
