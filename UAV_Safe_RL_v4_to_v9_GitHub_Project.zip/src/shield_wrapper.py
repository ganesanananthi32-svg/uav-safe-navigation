
import gymnasium as gym
import numpy as np
from .cbf import CBFShield
from .trigger import EventTrigger

class TrainingShieldWrapper(gym.Wrapper):
    """Deployment-style action shielding placed around an RL environment.

    Important: SB3's replay buffer still stores the policy action passed to this
    wrapper, while the wrapped environment executes the corrected action. This
    is the intentional v4-v8 diagnostic configuration described in the report.
    """
    def __init__(self, env, ttc_threshold=1.2):
        super().__init__(env)
        self.shield = CBFShield()
        self.trigger = EventTrigger(ttc_threshold=ttc_threshold)

    def reset(self, **kwargs):
        self.trigger.reset()
        return self.env.reset(**kwargs)

    def step(self, action):
        base = self.env.unwrapped
        d, po, vo = base.nearest_obstacle()
        if self.trigger.should_trigger(base.steps, base.pos, [(po, vo)]):
            accel,_ = self.shield.filter(np.asarray(action)*base.max_accel,
                                          base.pos, base.vel, po, vo)
            action = np.clip(accel/base.max_accel, -1, 1)
        return self.env.step(action)
