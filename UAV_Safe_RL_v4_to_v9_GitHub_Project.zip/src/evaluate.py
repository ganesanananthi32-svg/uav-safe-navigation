
import argparse, json, os
import numpy as np
from stable_baselines3 import SAC
from .env import UAVNavigationEnv
from .cbf import CBFShield
from .trigger import EventTrigger

def evaluate(model_path, episodes=50, seed=1000, use_filter=True):
    env = UAVNavigationEnv(num_obstacles=5, seed=seed, spacing_fix=True)
    model = SAC.load(model_path, device="cpu")
    shield = CBFShield()
    trigger = EventTrigger()
    rows=[]
    for ep in range(episodes):
        obs,_=env.reset(seed=seed+ep)
        done=False; trunc=False; ep_reward=0.; closest=1e9
        while not (done or trunc):
            action,_=model.predict(obs, deterministic=True)
            if use_filter:
                d,po,vo=env.nearest_obstacle()
                if trigger.should_trigger(env.steps,env.pos,[(po,vo)]):
                    accel,_=shield.filter(np.asarray(action)*3.0,env.pos,env.vel,po,vo)
                    action=np.clip(accel/3.0,-1,1)
            obs,r,done,trunc,info=env.step(action)
            ep_reward+=r
            closest=min(closest,info["closest_obstacle_distance"])
        rows.append(info | {"reward":ep_reward,"closest":closest})
    return rows

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("model")
    ap.add_argument("--episodes",type=int,default=50)
    ap.add_argument("--seed",type=int,default=1038)
    ap.add_argument("--no-filter",action="store_true")
    a=ap.parse_args()
    rows=evaluate(a.model,a.episodes,a.seed,not a.no_filter)
    out={"goal_rate":100*sum(r["goal_reached"] for r in rows)/len(rows),
         "collision_rate":100*sum(r["collision"] for r in rows)/len(rows),
         "timeout_rate":100*sum(r["timeout"] for r in rows)/len(rows),
         "mean_final_distance":float(np.mean([r["final_distance"] for r in rows])),
         "mean_closest_obstacle":float(np.mean([r["closest_obstacle_distance"] for r in rows]))}
    print(json.dumps(out,indent=2))
