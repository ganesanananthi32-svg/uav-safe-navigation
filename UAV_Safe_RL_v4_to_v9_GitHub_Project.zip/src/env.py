
import numpy as np
import gymnasium as gym
from gymnasium import spaces

class UAVNavigationEnv(gym.Env):
    """3-D point-mass UAV environment used by the final stable configuration."""
    metadata = {"render_modes": []}

    def __init__(self, num_obstacles=5, dt=0.05, episode_len=300,
                 target=(4.0, 0.0, 1.5), start=(0.0, 0.0, 1.0),
                 obstacle_radius=0.20, collision_threshold=0.30,
                 obstacle_speed=(0.15, 0.7), max_accel=3.0,
                 max_speed=2.0, k_nearest=5, seed=None,
                 spacing_fix=False):
        super().__init__()
        self.n = num_obstacles
        self.dt = dt
        self.episode_len = episode_len
        self.target = np.asarray(target, dtype=np.float32)
        self.start = np.asarray(start, dtype=np.float32)
        self.r_obs = obstacle_radius
        self.collision_threshold = collision_threshold
        self.speed_range = obstacle_speed
        self.max_accel = max_accel
        self.max_speed = max_speed
        self.k_nearest = k_nearest
        self.spacing_fix = spacing_fix
        self.bounds_lo = np.array([-5., -5., 0.3], dtype=np.float32)
        self.bounds_hi = np.array([ 5.,  5., 4.0], dtype=np.float32)
        # position(3), velocity(3), goal-relative(3), K obstacles*(relative pos 3 + velocity 3)
        obs_dim = 9 + 6*k_nearest
        self.observation_space = spaces.Box(-np.inf, np.inf, (obs_dim,), dtype=np.float32)
        self.action_space = spaces.Box(-1., 1., (3,), dtype=np.float32)
        self.rng = np.random.default_rng(seed)
        self.reset(seed=seed)

    def _spawn_obstacles(self):
        pos, vel = [], []
        attempts = 0
        while len(pos) < self.n and attempts < 5000:
            attempts += 1
            p = self.rng.uniform(self.bounds_lo, self.bounds_hi).astype(np.float32)
            # keep obstacles away from start/goal
            if np.linalg.norm(p-self.start) < 1.0 or np.linalg.norm(p-self.target) < 0.8:
                continue
            if self.spacing_fix and any(np.linalg.norm(p-q) < 0.45 for q in pos):
                continue
            speed = self.rng.uniform(*self.speed_range)
            direction = self.rng.normal(size=3)
            direction /= max(np.linalg.norm(direction), 1e-8)
            pos.append(p)
            vel.append((speed*direction).astype(np.float32))
        self.obs_pos = np.asarray(pos, dtype=np.float32)
        self.obs_vel = np.asarray(vel, dtype=np.float32)

    def _observation(self):
        rel = self.obs_pos - self.pos
        d = np.linalg.norm(rel, axis=1)
        order = np.argsort(d)[:self.k_nearest]
        slots = []
        for idx in order:
            slots.extend([*rel[idx], *self.obs_vel[idx]])
        while len(slots) < 6*self.k_nearest:
            slots.extend([*(self.bounds_hi-self.bounds_lo), 0., 0., 0.])
        return np.concatenate([self.pos, self.vel, self.target-self.pos,
                               np.asarray(slots[:6*self.k_nearest], dtype=np.float32)]).astype(np.float32)

    def nearest_obstacle(self):
        d = np.linalg.norm(self.obs_pos-self.pos, axis=1)
        i = int(np.argmin(d))
        return float(d[i]), self.obs_pos[i].copy(), self.obs_vel[i].copy()

    def step(self, action):
        action = np.clip(np.asarray(action, dtype=np.float32), -1, 1)
        accel = action*self.max_accel
        old_dist = np.linalg.norm(self.target-self.pos)
        self.vel += accel*self.dt
        speed = np.linalg.norm(self.vel)
        if speed > self.max_speed:
            self.vel *= self.max_speed/speed
        self.pos += self.vel*self.dt
        self.obs_pos += self.obs_vel*self.dt
        # reflect dynamic obstacles
        for j in range(self.n):
            for k in range(3):
                if self.obs_pos[j,k] < self.bounds_lo[k] or self.obs_pos[j,k] > self.bounds_hi[k]:
                    self.obs_pos[j,k] = np.clip(self.obs_pos[j,k], self.bounds_lo[k], self.bounds_hi[k])
                    self.obs_vel[j,k] *= -1

        self.steps += 1
        new_dist = np.linalg.norm(self.target-self.pos)
        d_obs, _, _ = self.nearest_obstacle()
        progress = old_dist-new_dist
        reward = 15.0*progress - 0.1*max(0., 0.8-d_obs) - 0.01*np.sum(accel**2) - 0.1
        terminated = False
        collision = d_obs <= self.collision_threshold
        goal = new_dist <= 0.20
        if goal:
            reward += 5.0
            terminated = True
        elif collision:
            reward -= 5.0
            terminated = True
        truncated = self.steps >= self.episode_len
        info = {"goal_reached": goal, "collision": collision,
                "timeout": truncated and not goal and not collision,
                "final_distance": float(new_dist),
                "closest_obstacle_distance": float(d_obs)}
        return self._observation(), float(reward), terminated, truncated, info

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.pos = self.start.copy()
        self.vel = np.zeros(3, dtype=np.float32)
        self.steps = 0
        self._spawn_obstacles()
        return self._observation(), {}
