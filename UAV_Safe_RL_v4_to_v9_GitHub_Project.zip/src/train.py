
import argparse, os, json
import numpy as np
from stable_baselines3 import SAC
from stable_baselines3.common.monitor import Monitor
from .env import UAVNavigationEnv
from .cbf import CBFShield
from .trigger import EventTrigger
from .shield_wrapper import TrainingShieldWrapper

def train(total_steps, obstacles=5, seed=42, shield_during_training=False,
          spacing_fix=False, ttc_threshold=1.2, model_dir="models",
          network=(128,128), buffer_size=50000, learning_starts=1000):
    os.makedirs(model_dir, exist_ok=True)
    base_env = UAVNavigationEnv(num_obstacles=obstacles, seed=seed,
                                spacing_fix=spacing_fix)
    if shield_during_training:
        base_env = TrainingShieldWrapper(base_env, ttc_threshold=ttc_threshold)
    env = Monitor(base_env)
    model = SAC("MlpPolicy", env, learning_rate=3e-4,
                buffer_size=buffer_size, batch_size=256, tau=0.005,
                gamma=0.99, train_freq=1, gradient_steps=1,
                learning_starts=learning_starts,
                policy_kwargs=dict(net_arch=list(network)),
                seed=seed, verbose=1, device="cpu")
    # If enabled, the shield substitutes the executed action during rollout.
    # This is intentionally retained for v4-v8 diagnostic reproduction.
    model.learn(total_timesteps=total_steps,
                callback=None, progress_bar=True)
    path=os.path.join(model_dir, f"sac_{total_steps}_{seed}.zip")
    model.save(path)
    return path

if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--steps",type=int,default=150000)
    ap.add_argument("--obstacles",type=int,default=5)
    ap.add_argument("--seed",type=int,default=42)
    ap.add_argument("--spacing-fix",action="store_true")
    ap.add_argument("--ttc",type=float,default=1.2)
    ap.add_argument("--buffer",type=int,default=50000)
    args=ap.parse_args()
    train(total_steps=args.steps, obstacles=args.obstacles, seed=args.seed,
          shield_during_training=True, spacing_fix=args.spacing_fix,
          ttc_threshold=args.ttc, buffer_size=args.buffer)
