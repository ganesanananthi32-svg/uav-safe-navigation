# v4 → v9 project timeline

This timeline follows the supplied Phase 2 continuation report and final presentation.

## v4 — Baseline
Five dynamic obstacles in the scaled environment. The safety filter remained in the training loop.
150k SAC steps. Verified baseline: 0% goal, 2% collision, 98% timeout.

## v5 — Training budget / TTC diagnostic
Extended training to 300k steps and relaxed TTC threshold to 2.0 s. Goal reach remained 0%.
The evaluation episode length remained pinned at 951 steps in the diagnostic.

## v6 — Curriculum staging
N=2 → N=3 → N=5, loading the model between stages. This exposed replay-buffer discontinuity:
SAC.load restores policy parameters but not replay-buffer contents.

## v7 — Buffer continuity fix
Same curriculum, but replay buffer explicitly saved/restored between stages. Goal reach still 0%.

## v8 — Obstacle geometry fix
Added minimum pairwise obstacle spacing of 0.45 m. The environment bug was fixed and verified,
but goal reach remained 0%.

## v9 — Corrected training / final stable model
Safety-filter action substitution was removed from SAC training. The policy is trained on its own
executed action and evaluated with the CBF shield at deployment. The final presentation reports
48/50 goal reach (96%), 2/50 crashes (4%), 0% timeout, mean final distance 0.215 m.

IMPORTANT: v4-v8 recorded metrics and the v9 summary are transcribed from the supplied report/presentation.
Running the included training scripts produces fresh experiments and should be described as such.
