# UAV Safe RL + CBF — v4 to v9 progression

This repository is organized to make the project progression visible rather than presenting one
large final code drop.

## Structure

- `src/` — actual reusable environment, SAC training, event trigger, and CBF shield implementation.
- `versions/v4_baseline/` — baseline configuration and training/evaluation scripts.
- `versions/v5_training_extension_ttc/` — 300k-step + TTC diagnostic.
- `versions/v6_curriculum_buffer_reset/` — curriculum with replay-buffer reset.
- `versions/v7_curriculum_buffer_continuity/` — curriculum with replay-buffer preservation.
- `versions/v8_spacing_fix/` — obstacle-spacing bug fix.
- `versions/v9_final_stable_corrected_training/` — corrected training and final stable point-mass model.
- `results/` — images extracted from the supplied final presentation.
- `results_by_version.csv` — report-backed progression table.
- `VERSION_TIMELINE.md` — concise explanation of what changed at every stage.

## Important distinction

The Python files are actual runnable experiment code. The metric JSON/CSV files and the presentation
figures are **recorded report/presentation results**, not claims that this ZIP freshly reproduced those
numbers. This distinction is important for reproducibility.

## Run from the project root

Install:
    pip install -r requirements.txt

Example:
    python versions/v4_baseline/train_v4.py
    python versions/v9_final_stable_corrected_training/train_v9.py

For evaluation, first train a model, then run the corresponding evaluate script.

The supplied final presentation documents the final stable configuration as a 3-D point-mass environment,
5 dynamic obstacles, 300 steps / 15 s, 1,000,000 SAC timesteps, and a deployment-time CBF shield.
